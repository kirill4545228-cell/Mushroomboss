# Mushroom Realm (Fabric 1.20.1)

Build: push this repo to GitHub, Actions -> `build` -> artifact `mushroom-realm-jar` (use the jar without `-dev`).
Needs Fabric Loader 0.15+ and Fabric API 0.92.2+1.20.1.

- Mushroom Beetle: spawns in mushroom fields / dark forest / swamp, drops shards, rarely Spore Heart.
- Mushroom Colossus: use Spore Heart on a giant mushroom block. Drops Fungal Core.
- Mushroom Sword: shards + Fungal Core + stick (` S `/`SCS`/` T `).

- Mushroom Snail (neutral): hides in its shell when hurt, then spits poison spore bombs; spreads mycelium; feed it a mushroom.
- Mushroom Mimic (hostile): disguised as a small mushroom, ambushes players, pounces and bites (blindness + hunger).
- `blockbench/` contains the editable .bbmodel files of the snail and the mimic (the mod itself uses the copies in `assets/mushroomrealm/bbmodels/`).

package com.mushroomrealm.entity;

import java.util.EnumSet;
import java.util.List;

import com.mushroomrealm.registry.ModItems;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.thrown.PotionEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.potion.PotionUtil;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.GameRules;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;

/**
 * Mushroom Snail (neutral).
 * - Peaceful until attacked.
 * - When hurt it hides in its shell for 5 seconds (takes only 20% damage, no knockback).
 * - After coming out it spits spore bombs (poison + slowness) at whoever hurt it.
 * - Slowly turns dirt / grass under it into mycelium and grows mushrooms on it.
 * - Feed it a mushroom: heals it and it may leave a Mushroom Shard behind.
 */
public class MushroomSnailEntity extends BbCreatureEntity {
	public static final int ACTION_HIDE = 1;
	public static final int ACTION_EMERGE = 2;
	public static final int ACTION_SPIT = 3;

	private int spitCooldown = 60;
	private int hideCooldown;
	private int trailTimer;

	public MushroomSnailEntity(EntityType<? extends MushroomSnailEntity> type, World world) {
		super(type, world);
		this.experiencePoints = 3;
	}

	public static DefaultAttributeContainer.Builder createAttributes() {
		return MobEntity.createMobAttributes()
				.add(EntityAttributes.GENERIC_MAX_HEALTH, 14.0)
				.add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.17)
				.add(EntityAttributes.GENERIC_FOLLOW_RANGE, 16.0)
				.add(EntityAttributes.GENERIC_ARMOR, 4.0);
	}

	public static boolean canSpawnSnail(EntityType<MushroomSnailEntity> type, ServerWorldAccess world, SpawnReason reason, BlockPos pos, Random random) {
		BlockState below = world.getBlockState(pos.down());
		return (below.isOf(Blocks.GRASS_BLOCK) || below.isOf(Blocks.MYCELIUM)) && world.getBaseLightLevel(pos, 0) > 8;
	}

	@Override
	protected void initGoals() {
		this.goalSelector.add(0, new SwimGoal(this));
		this.goalSelector.add(1, new SpitGoal());
		this.goalSelector.add(3, new WanderAroundFarGoal(this, 0.7));
		this.goalSelector.add(4, new LookAtEntityGoal(this, PlayerEntity.class, 6.0F));
		this.goalSelector.add(5, new LookAroundGoal(this));
		this.targetSelector.add(1, new RevengeGoal(this));
	}

	private class SpitGoal extends Goal {
		SpitGoal() {
			this.setControls(EnumSet.of(Goal.Control.LOOK));
		}

		@Override
		public boolean canStart() {
			MushroomSnailEntity snail = MushroomSnailEntity.this;
			LivingEntity target = snail.getTarget();
			if (target == null || !target.isAlive() || snail.isBusy() || snail.spitCooldown > 0) {
				return false;
			}
			double distSq = snail.squaredDistanceTo(target);
			return distSq > 4.0 && distSq < 196.0 && snail.canSee(target);
		}

		@Override
		public boolean shouldContinue() {
			return false;
		}

		@Override
		public void start() {
			MushroomSnailEntity snail = MushroomSnailEntity.this;
			LivingEntity target = snail.getTarget();
			if (target != null) {
				snail.getLookControl().lookAt(target, 60.0F, 60.0F);
			}
			snail.startAction(ACTION_SPIT, 12);
			snail.spitCooldown = 70;
		}
	}

	@Override
	protected boolean isImmobile() {
		int action = this.getAction();
		return super.isImmobile() || action == ACTION_HIDE || action == ACTION_EMERGE || action == ACTION_SPIT;
	}

	@Override
	public void tick() {
		super.tick();
		if (this.getWorld().isClient) {
			return;
		}
		if (this.spitCooldown > 0) {
			this.spitCooldown--;
		}
		if (this.hideCooldown > 0) {
			this.hideCooldown--;
		}
		if (this.isOnGround() && ++this.trailTimer >= 30) {
			this.trailTimer = 0;
			this.spreadMycelium();
		}
	}

	private void spreadMycelium() {
		World world = this.getWorld();
		if (!world.getGameRules().getBoolean(GameRules.DO_MOB_GRIEFING)) {
			return;
		}
		BlockPos feet = this.getBlockPos();
		BlockPos below = feet.down();
		BlockState state = world.getBlockState(below);
		if (state.isOf(Blocks.GRASS_BLOCK) || state.isOf(Blocks.DIRT)) {
			world.setBlockState(below, Blocks.MYCELIUM.getDefaultState());
		} else if (state.isOf(Blocks.MYCELIUM) && world.isAir(feet) && this.random.nextInt(6) == 0) {
			BlockState mushroom = this.random.nextBoolean() ? Blocks.RED_MUSHROOM.getDefaultState() : Blocks.BROWN_MUSHROOM.getDefaultState();
			if (mushroom.canPlaceAt(world, feet)) {
				world.setBlockState(feet, mushroom);
			}
		}
	}

	@Override
	protected void onActionTick(int action, int elapsed) {
		if (action == ACTION_SPIT && elapsed == 7) {
			this.fireSpit();
		}
	}

	@Override
	protected void onActionEnd(int action) {
		if (action == ACTION_HIDE) {
			this.hideCooldown = 200;
			this.startAction(ACTION_EMERGE, 10);
		}
	}

	private void fireSpit() {
		LivingEntity target = this.getTarget();
		if (target == null || !(this.getWorld() instanceof ServerWorld sw)) {
			return;
		}
		PotionEntity bomb = new PotionEntity(sw, this);
		ItemStack stack = new ItemStack(Items.SPLASH_POTION);
		PotionUtil.setCustomPotionEffects(stack, List.of(
				new StatusEffectInstance(StatusEffects.POISON, 100, 0),
				new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 1)));
		bomb.setItem(stack);
		Vec3d v = target.getVelocity();
		double dx = target.getX() + v.x - this.getX();
		double dy = target.getEyeY() - 1.1 - this.getY();
		double dz = target.getZ() + v.z - this.getZ();
		double horizontal = Math.sqrt(dx * dx + dz * dz);
		bomb.setPitch(bomb.getPitch() + 20.0F);
		bomb.setVelocity(dx, dy + horizontal * 0.2, dz, 0.75F, 8.0F);
		sw.spawnEntity(bomb);
		sw.playSound(null, this.getX(), this.getY(), this.getZ(), SoundEvents.ENTITY_SLIME_SQUISH, SoundCategory.NEUTRAL, 1.0F, 0.8F);
	}

	// ------------------------------------------------------------ hurt / hide

	@Override
	public boolean damage(DamageSource source, float amount) {
		if (this.getAction() == ACTION_HIDE) {
			amount *= 0.2F;
		}
		boolean result = super.damage(source, amount);
		if (result && !this.getWorld().isClient && this.isAlive() && this.getAction() != ACTION_HIDE && this.hideCooldown <= 0) {
			this.getNavigation().stop();
			this.startAction(ACTION_HIDE, 100);
		}
		return result;
	}

	@Override
	public void takeKnockback(double strength, double x, double z) {
		if (this.getAction() == ACTION_HIDE) {
			return;
		}
		super.takeKnockback(strength, x, z);
	}

	// ------------------------------------------------------------ feeding

	@Override
	public ActionResult interactMob(PlayerEntity player, Hand hand) {
		ItemStack stack = player.getStackInHand(hand);
		if (stack.isOf(Items.RED_MUSHROOM) || stack.isOf(Items.BROWN_MUSHROOM)) {
			if (!this.getWorld().isClient) {
				this.heal(4.0F);
				if (!player.getAbilities().creativeMode) {
					stack.decrement(1);
				}
				if (this.random.nextInt(3) == 0) {
					this.dropItem(ModItems.MUSHROOM_SHARD);
				}
				if (this.getWorld() instanceof ServerWorld sw) {
					sw.spawnParticles(ParticleTypes.HEART, this.getX(), this.getBodyY(1.0), this.getZ(), 5, 0.3, 0.3, 0.3, 0.02);
				}
			}
			return ActionResult.success(this.getWorld().isClient);
		}
		return super.interactMob(player, hand);
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return SoundEvents.ENTITY_SLIME_HURT_SMALL;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return SoundEvents.ENTITY_SLIME_DEATH_SMALL;
	}

	@Override
	protected void playStepSound(BlockPos pos, BlockState state) {
		this.playSound(SoundEvents.ENTITY_SLIME_SQUISH_SMALL, 0.1F, 1.0F);
	}
}

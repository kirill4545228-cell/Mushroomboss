package com.mushroomrealm.entity;

/** Implemented by mobs that are drawn from a Blockbench model (read by the client renderer). */
public interface BbAnimated {
	/** 0 = no action, otherwise an id defined by the mob. */
	int getAction();

	/** Seconds since the current action started (client side). */
	float getActionTime(float tickDelta);

	boolean isMovingForAnimation();
}

package com.mushroomrealm.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.world.World;

/** Same action system as BbMobEntity, but for non-hostile (neutral) mobs. */
public abstract class BbCreatureEntity extends PathAwareEntity implements BbAnimated {
	protected static final TrackedData<Integer> ACTION = DataTracker.registerData(BbCreatureEntity.class, TrackedDataHandlerRegistry.INTEGER);

	private int actionTicks;
	private int actionLength;
	private int clientActionStart;

	protected BbCreatureEntity(EntityType<? extends PathAwareEntity> type, World world) {
		super(type, world);
	}

	@Override
	protected void initDataTracker() {
		super.initDataTracker();
		this.dataTracker.startTracking(ACTION, 0);
	}

	@Override
	public int getAction() {
		return this.dataTracker.get(ACTION);
	}

	protected void startAction(int action, int ticks) {
		this.actionTicks = ticks;
		this.actionLength = ticks;
		this.dataTracker.set(ACTION, action);
	}

	protected boolean isBusy() {
		return this.getAction() != 0;
	}

	@Override
	public float getActionTime(float tickDelta) {
		return (this.age - this.clientActionStart + tickDelta) / 20.0F;
	}

	@Override
	public boolean isMovingForAnimation() {
		return this.limbAnimator.getSpeed() > 0.02F;
	}

	@Override
	public void onTrackedDataSet(TrackedData<?> data) {
		super.onTrackedDataSet(data);
		if (ACTION.equals(data) && this.getWorld().isClient) {
			this.clientActionStart = this.age;
		}
	}

	@Override
	public void tick() {
		super.tick();
		if (!this.getWorld().isClient && this.actionTicks > 0) {
			this.actionTicks--;
			int action = this.getAction();
			this.onActionTick(action, this.actionLength - this.actionTicks);
			if (this.actionTicks == 0) {
				this.dataTracker.set(ACTION, 0);
				this.onActionEnd(action);
			}
		}
	}

	protected void onActionTick(int action, int elapsed) {
	}

	protected void onActionEnd(int action) {
	}
}

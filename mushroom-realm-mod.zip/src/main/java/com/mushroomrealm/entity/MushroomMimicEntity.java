package com.mushroomrealm.entity;

import com.mushroomrealm.registry.ModEntities;
import net.minecraft.block.BlockState;
import net.minecraft.entity.AreaEffectCloudEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Mushroom Mimic (hostile ambusher).
 * - Looks like a harmless little mushroom and stands perfectly still.
 * - When a player comes within 4.5 blocks (or it is hit) it pops open and attacks.
 * - Pounces from a distance, bites with Blindness + Hunger.
 * - If it loses its prey for 15 seconds it disguises itself again and recovers health.
 * - Bursts into a blinding spore cloud on death.
 */
public class MushroomMimicEntity extends BbMobEntity {
	public static final int ACTION_BITE = 1;
	public static final int ACTION_POUNCE = 2;
	public static final int ACTION_EMERGE = 3;

	private static final TrackedData<Boolean> DISGUISED = DataTracker.registerData(MushroomMimicEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

	private int pounceCooldown = 40;
	private int lostTargetTicks;

	public MushroomMimicEntity(EntityType<? extends MushroomMimicEntity> type, World world) {
		super(type, world);
		this.experiencePoints = 10;
	}

	public static DefaultAttributeContainer.Builder createAttributes() {
		return HostileEntity.createHostileAttributes()
				.add(EntityAttributes.GENERIC_MAX_HEALTH, 30.0)
				.add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.32)
				.add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 6.0)
				.add(EntityAttributes.GENERIC_FOLLOW_RANGE, 20.0)
				.add(EntityAttributes.GENERIC_ARMOR, 2.0);
	}

	public static boolean canSpawnMimic(EntityType<MushroomMimicEntity> type, ServerWorldAccess world, SpawnReason reason, BlockPos pos, Random random) {
		return HostileEntity.canSpawnInDark(type, world, reason, pos, random);
	}

	@Override
	protected void initDataTracker() {
		super.initDataTracker();
		this.dataTracker.startTracking(DISGUISED, true);
	}

	public boolean isDisguised() {
		return this.dataTracker.get(DISGUISED);
	}

	@Override
	public void onTrackedDataSet(TrackedData<?> data) {
		super.onTrackedDataSet(data);
		if (DISGUISED.equals(data)) {
			this.calculateDimensions();
		}
	}

	@Override
	public EntityDimensions getDimensions(EntityPose pose) {
		if (this.isDisguised()) {
			return EntityDimensions.fixed(0.7F, 0.7F);
		}
		return super.getDimensions(pose);
	}

	@Override
	protected boolean isImmobile() {
		return super.isImmobile() || this.isDisguised();
	}

	@Override
	protected void initGoals() {
		this.goalSelector.add(0, new SwimGoal(this));
		this.goalSelector.add(2, new MeleeAttackGoal(this, 1.2, false));
		this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.8));
		this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8.0F));
		this.goalSelector.add(6, new LookAroundGoal(this));
		this.targetSelector.add(1, new RevengeGoal(this));
		this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
	}

	private void wake(@Nullable LivingEntity cause) {
		if (!this.isDisguised()) {
			return;
		}
		this.dataTracker.set(DISGUISED, false);
		this.startAction(ACTION_EMERGE, 12);
		this.lostTargetTicks = 0;
		if (cause != null) {
			this.setTarget(cause);
		}
		this.playSound(SoundEvents.ENTITY_RAVAGER_ROAR, 0.8F, 1.6F);
	}

	@Override
	public void tick() {
		super.tick();
		if (this.getWorld().isClient) {
			return;
		}
		if (this.isDisguised()) {
			if (this.age % 5 == 0) {
				PlayerEntity player = this.getWorld().getClosestPlayer(this, 4.5);
				if (player != null && !player.isSpectator()) {
					this.wake(player);
				}
			}
		} else {
			if (this.getTarget() == null) {
				this.lostTargetTicks++;
			} else {
				this.lostTargetTicks = 0;
			}
			if (this.lostTargetTicks > 300 && this.getWorld().getClosestPlayer(this, 14.0) == null) {
				this.dataTracker.set(DISGUISED, true);
				this.getNavigation().stop();
				this.setVelocity(Vec3d.ZERO);
				this.heal(10.0F);
			}
		}
	}

	@Override
	protected void mobTick() {
		super.mobTick();
		if (this.pounceCooldown > 0) {
			this.pounceCooldown--;
		}
		LivingEntity target = this.getTarget();
		if (target != null && !this.isBusy() && this.isOnGround() && this.pounceCooldown <= 0) {
			double distSq = this.squaredDistanceTo(target);
			if (distSq > 16.0 && distSq < 81.0) {
				this.startAction(ACTION_POUNCE, 16);
				this.pounceCooldown = 80 + this.random.nextInt(60);
			}
		}
	}

	@Override
	protected void onActionTick(int action, int elapsed) {
		if (action == ACTION_POUNCE) {
			if (elapsed < 6) {
				this.getNavigation().stop();
			} else if (elapsed == 6) {
				LivingEntity target = this.getTarget();
				if (target != null) {
					Vec3d dir = new Vec3d(target.getX() - this.getX(), 0.0, target.getZ() - this.getZ()).normalize();
					this.setVelocity(dir.x * 0.9, 0.55, dir.z * 0.9);
					this.velocityDirty = true;
				}
			}
		}
	}

	@Override
	public boolean tryAttack(Entity target) {
		boolean hit = super.tryAttack(target);
		if (hit) {
			if (!this.isBusy()) {
				this.startAction(ACTION_BITE, 10);
			}
			if (target instanceof LivingEntity living) {
				living.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 40, 0), this);
				living.addStatusEffect(new StatusEffectInstance(StatusEffects.HUNGER, 200, 0), this);
			}
		}
		return hit;
	}

	@Override
	public boolean damage(DamageSource source, float amount) {
		if (this.isDisguised() && !this.getWorld().isClient) {
			Entity attacker = source.getAttacker();
			this.wake(attacker instanceof LivingEntity living ? living : null);
		}
		return super.damage(source, amount);
	}

	@Override
	public void onDeath(DamageSource damageSource) {
		super.onDeath(damageSource);
		if (!this.getWorld().isClient) {
			AreaEffectCloudEntity cloud = new AreaEffectCloudEntity(this.getWorld(), this.getX(), this.getY(), this.getZ());
			cloud.setOwner(this);
			cloud.setRadius(2.5F);
			cloud.setDuration(80);
			cloud.setParticleType(ParticleTypes.SPORE_BLOSSOM_AIR);
			cloud.addEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 60, 0));
			cloud.addEffect(new StatusEffectInstance(StatusEffects.POISON, 60, 0));
			this.getWorld().spawnEntity(cloud);
		}
	}

	@Override
	public boolean canHaveStatusEffect(StatusEffectInstance effect) {
		if (effect.getEffectType() == StatusEffects.POISON || effect.getEffectType() == StatusEffects.BLINDNESS) {
			return false;
		}
		return super.canHaveStatusEffect(effect);
	}

	@Override
	public void writeCustomDataToNbt(NbtCompound nbt) {
		super.writeCustomDataToNbt(nbt);
		nbt.putBoolean("Disguised", this.isDisguised());
	}

	@Override
	public void readCustomDataFromNbt(NbtCompound nbt) {
		super.readCustomDataFromNbt(nbt);
		if (nbt.contains("Disguised")) {
			this.dataTracker.set(DISGUISED, nbt.getBoolean("Disguised"));
		}
	}

	@Override
	protected SoundEvent getAmbientSound() {
		return this.isDisguised() ? null : SoundEvents.ENTITY_SPIDER_AMBIENT;
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return SoundEvents.ENTITY_SPIDER_HURT;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return SoundEvents.ENTITY_SPIDER_DEATH;
	}

	@Override
	protected void playStepSound(BlockPos pos, BlockState state) {
		this.playSound(SoundEvents.ENTITY_SPIDER_STEP, 0.15F, 1.0F);
	}
}

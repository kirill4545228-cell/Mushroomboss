package com.mushroomrealm.client.render;

import com.mushroomrealm.entity.MushroomMimicEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;

public class MimicRenderer extends BbEntityRenderer<MushroomMimicEntity> {
	public MimicRenderer(EntityRendererFactory.Context ctx) {
		super(ctx, "mushroom_mimic", 1.4F, 0.7F);
	}

	@Override
	protected String actionAnimation(int action) {
		return switch (action) {
			case MushroomMimicEntity.ACTION_BITE -> "bite";
			case MushroomMimicEntity.ACTION_POUNCE -> "pounce";
			case MushroomMimicEntity.ACTION_EMERGE -> "emerge";
			default -> "idle";
		};
	}

	@Override
	protected String locomotionAnimation(MushroomMimicEntity entity) {
		if (entity.isDisguised()) {
			return "hidden";
		}
		return entity.isMovingForAnimation() ? "walk" : "idle";
	}
}

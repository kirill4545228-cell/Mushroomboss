package com.mushroomrealm.client.render;

import com.mushroomrealm.entity.MushroomSnailEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;

public class SnailRenderer extends BbEntityRenderer<MushroomSnailEntity> {
	public SnailRenderer(EntityRendererFactory.Context ctx) {
		super(ctx, "mushroom_snail", 1.25F, 0.5F);
	}

	@Override
	protected String actionAnimation(int action) {
		return switch (action) {
			case MushroomSnailEntity.ACTION_HIDE -> "hide";
			case MushroomSnailEntity.ACTION_EMERGE -> "emerge";
			case MushroomSnailEntity.ACTION_SPIT -> "spit";
			default -> "idle";
		};
	}

	@Override
	protected String locomotionAnimation(MushroomSnailEntity entity) {
		return entity.isMovingForAnimation() ? "walk" : "idle";
	}
}
